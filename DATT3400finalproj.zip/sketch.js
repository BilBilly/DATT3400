let cols, rows;
let scl = 20;
let terrain = [];
let flying = 0;
let waterHeight = -40;
let caveHeight = -60;
let peakHeight = 100;
let treeHeight = 50;
let detailLevel = 80;
let birds = [];
let clouds = [];
let stars = [];

let treeGrowth = 0;
let rising = false; // Flag to check if the terrain is rising
let riseAmount = 0; // Amount the terrain will rise
let targetRise = 30; // Max rise height
let riseSpeed = 1; // Speed of rising

function setup() {
  createCanvas(800, 600, WEBGL);
  cols = width / scl;
  rows = height / scl;
  noiseDetail(8, 0.5);


  for (let i = 0; i < 30; i++) {
    birds.push({
      x: random(-width, width),
      y: random(-height / 2, -height / 3),
      
      z: random(-100, 100),
      
      
      
      speed: random(1, 3),
      offset: random(TWO_PI)
    });
  }

 
  for (let i = 0; i < 30; i++) {
    clouds.push({
      x: random(-width, width),
      y: random(-height / 2, -height / 3),
      z: random(-100, 100),
      speed: random(0.5, 1.5)
    });
  }

 
  for (let i = 0; i < 600; i++) {
    stars.push({
      x: random(-width, width),
      y: random(-height, 0),
      z: random(-300, 0),
      brightness: random(180, 255),
      flickerSpeed: random(0.005, 0.02)
    });
  }
  
  
}

function draw() {
  background(10, 10, 50);
  drawStars();
  rotateX(PI / 3.2);
  translate(-width / 2, -height / 3);

  ambientLight(100);
  directionalLight(255, 255, 255, -1, -1, -1);

  flying -= 0.02;
  let yOffset = flying;

  // Terrain generation
  for (let y = 0; y < rows; y++) {
    terrain[y] = [];
    let xOffset = 0;
    for (let x = 0; x < cols; x++) {
      let baseNoise = noise(xOffset, yOffset) * 1.2;
      let detailNoise = noise(xOffset * 2, yOffset * 2) * 0.3;
      let variation = random(-2, 2); 
      
      
      let elevation = map(baseNoise + detailNoise, 0, 1.5, -150, 150) + variation;

      terrain[y][x] = elevation;
      xOffset += 0.12;
    }
    yOffset += 0.12;
  }

  // Animate the rise effect on clicked terrain
  if (rising) {
    riseAmount += riseSpeed;
    if (riseAmount >= targetRise) {
      rising = false; // Stop rising when the target is reached
    }
  }

  // Terrain drawing
  for (let y = 0; y < rows - 1; y++) {
    for (let x = 0; x < cols - 1; x++) {
      let a = createVector(x * scl, y * scl, terrain[y][x] + (x === clickX && y === clickY ? riseAmount : 0)); // Apply rise to clicked point
      let b = createVector((x + 1) * scl, y * scl, terrain[y][x + 1] + (x === clickX && y === clickY ? riseAmount : 0));
      let c = createVector((x + 1) * scl, (y + 1) * scl, terrain[y + 1][x + 1] + (x === clickX && y === clickY ? riseAmount : 0));
      let d = createVector(x * scl, (y + 1) * scl, terrain[y + 1][x] + (x === clickX && y === clickY ? riseAmount : 0));

      let elevation = (terrain[y][x] + terrain[y][x + 1] + terrain[y + 1][x + 1] + terrain[y + 1][x]) / 4;

      // Terrain color logic (adjusting for water, cave, peak, etc.)
      if (elevation < waterHeight + 10 && elevation > waterHeight - 10) {
        fill(50, 150, 255, 180); // water
      } else if (elevation < waterHeight) {
        fill(0, 70, 200); // deeper water
      } else if (elevation < caveHeight) {
        fill(30, 30, 30); // cave rocks
      } else if (elevation > peakHeight) {
        fill(255, 250, 250); // snow on peaks
      } else {
        let greenShade = map(elevation, caveHeight, peakHeight, 80, 220);
        let brownTint = map(elevation, waterHeight, caveHeight, 60, 100); // dirtier soil color
        fill(100 + brownTint, greenShade, 50); 
      }

      beginShape();
      vertex(a.x, a.y, a.z);
      vertex(b.x, b.y, b.z);
      vertex(c.x, c.y, c.z);
      vertex(d.x, d.y, d.z);
      endShape(CLOSE);
    }
  }

  treeGrowth += 0.01;
  addTrees();
  addBirds();
  addClouds();
}

let clickX = -1;
let clickY = -1;

function mousePressed() {
  // Convert mouse position to terrain grid
  let x = int((mouseX - width / 2) / scl);
  let y = int((mouseY - height / 3) / scl);

  // Ensure x, y are within bounds
  if (x >= 0 && x < cols && y >= 0 && y < rows) {
    clickX = x;
    clickY = y;
    rising = true; // Start rising the terrain at the clicked point
    riseAmount = 0; // Reset rise amount
  }
}

function addTrees() {
  for (let i = 0; i < min(treeGrowth * 50, 50); i++) {
    let col = int(random(cols - 1));
    let row = int(random(rows - 1));
    let x = col * scl;
    let y = row * scl;
    let z = terrain[row][col];

    if (z > waterHeight) {
      push();
      translate(x - width / 10, y - height / 5, z);
      drawTree();
      pop();
    }
  }
}

function drawTree() {
  let trunkHeight = random(8, 12);
  let leafSize = random(5, 8);

  fill(139, 69, 19); // Tree trunk color
  noStroke();
  cylinder(1.5, trunkHeight);

  fill(34, 139, 34); // Leaves
  translate(0, -trunkHeight, 0);
  sphere(leafSize);
}

function addBirds() {
  for (let bird of birds) {
    bird.x += bird.speed;
    bird.y += sin(frameCount * 0.05 + bird.offset) * 0.5;

    if (bird.x > width) bird.x = -width;
    push();
    translate(bird.x, bird.y, bird.z);
    drawBird();
    pop();
  }
}

function drawBird() {
  fill(255, 255, 255);
  beginShape();
  vertex(0, 0, 0);
  vertex(15, -8, 0);
  vertex(30, 0, 0);
  vertex(15, 8, 0);
  endShape(CLOSE);
}

function addClouds() {
  for (let cloud of clouds) {
    cloud.x += cloud.speed;
    cloud.y += sin(frameCount * 0.01) * 0.2;

    if (cloud.x > width) cloud.x = -width;
    push();
    translate(cloud.x, cloud.y, cloud.z);
    drawCloud();
    pop();
  }
}

function drawCloud() {
  fill(200);
  noStroke();
  for (let i = 0; i < 3; i++) {
    translate(i * 15, random(-5, 5), 0);
    sphere(25);
  }
}

function drawStars() {
  push();
  translate(-width / 100, -height / 8, -1000);
  for (let star of stars) {
    
    
    let flicker = sin(frameCount * star.flickerSpeed) * 50;
    fill(star.brightness + flicker);
    
    noStroke();
    
    

 
    ellipse(star.x, star.y, map(star.z, -300, 0, 0.5, 3), map(star.z, -300, 0, 0.5, 3));
  }
  pop();
}

function keyPressed() {
  if (key === 's' || key === 'S') {
    
    saveCanvas('detailed-terrain-with-trees-birds-clouds', 'png');
  }
}

